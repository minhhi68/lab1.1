// import logo from './logo.svg';
import './App.css';
import Footer from './components/Footer';
import Main2 from './components/Main2';
import Navigation from './components/Navigation';



function App() {
  return (
    <div className="App">
     <Navigation/> 
     <Main2/>
   <Footer/>
    </div>
  );
}

// class Content extends React.Component{
//   componentWillMount(){
//     console.log()
//   }
// }
export default App;
