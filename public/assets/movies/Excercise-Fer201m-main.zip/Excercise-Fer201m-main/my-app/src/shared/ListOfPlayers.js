export const Players =[
    {id: 1, name: 'Cristiano Ronaldo', club: 'Manchester United', img:'assets/images/cr.jpg'},
    {id: 2, name: 'Kante', club: 'Chelsea', img:'assets/images/kante.jpg'},
    {id: 2, name: 'Messi', club: 'PSG', img:'assets/images/messi.jpg'},
    {id: 2, name: 'Neymar12', club: 'PSG',img:'assets/images/neymar.jpg'},
    {id: 2, name: 'Kane', club: 'Tottemham',img:'assets/images/kane.jpg' },
    {id: 2, name: 'Haaland', club: 'Manchester City', img:'assets/images/haaland.jpg'}
  ];
