export const Films =[
    {id: 1, name: 'End of the Road ', titles: 'Netflix Film', img:'assets/images/1.jpg', year :2022, nation:'United States'},
    {id: 2, name: 'Love in the Villa', titles: 'Netflix Film', img:'assets/images/2.jpg', year :2022, nation:'United States'},
    {id: 3, name: 'I Came By', titles: 'Netflix Film', img:'assets/images/3.jpg', year :2022, nation:'United States'},
    {id: 4, name: 'Me Time', titles: 'Netflix Film',img:'assets/images/4.jpg', year :2022, nation:'United States'},
    {id: 5, name: 'Morbius', titles: 'Netflix Film',img:'assets/images/5.jpg', year :2022, nation:'United States' },
    {id: 6, name: 'White Chicks', titles: 'Netflix Film ', img:'assets/images/6.jpg', year :2022, nation:'United States'},
    {id: 7, name: 'Despicable Me 2', titles: 'Netflix Film ', img:'assets/images/7.jpg', year :2022, nation:'United States'},
    {id: 8, name: 'Triple 9', titles: 'Netflix Film ', img:'assets/images/8.jpg', year :2022, nation:'United States'},
    {id: 9, name: 'Labor Day', titles: 'Netflix Film', img:'assets/images/9.jpg', year :2022, nation:'United States'}
  ];
