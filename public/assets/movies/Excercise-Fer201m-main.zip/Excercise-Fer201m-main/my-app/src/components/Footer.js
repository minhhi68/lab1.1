import React, { Component } from 'react'

export default class Footer extends Component {
  render() {
    return (
      <div className='footer'>
       <h4>Coppyright@2022</h4>
      </div>
    )
  }
}
